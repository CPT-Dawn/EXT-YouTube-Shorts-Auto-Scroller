// ------------------------------
// CONSTANT SELECTORS VARIABLES
// ------------------------------
const VIDEOS_LIST_SELECTORS = [
  ".reel-video-in-sequence",
  ".reel-video-in-sequence-new",
];
const CURRENT_SHORT_SELECTOR = "ytd-reel-video-renderer";
const LIKE_BUTTON_SELECTOR = "#like-button button";
const DISLIKE_BUTTON_SELECTOR = "#dislike-button button";
const COMMENTS_SELECTOR =
  "ytd-engagement-panel-section-list-renderer[target-id='engagement-panel-comments-section']";
const LIKES_COUNT_SELECTOR =
  "#factoids > factoid-renderer:nth-child(1) > div > span.ytwFactoidRendererValue > span";
const VIEW_COUNT_SELECTOR =
  "#factoids > view-count-factoid-renderer > factoid-renderer > div > span.ytwFactoidRendererValue > span";
const COMMENTS_COUNT_SELECTORS = [
  "#comments-button > ytd-button-renderer > yt-button-shape > label > div > span",
  "#button-bar > reel-action-bar-view-model > button-view-model:nth-of-type(1) > label > div > span",
];
const DESCRIPTION_TAGS_SELECTOR = "#title > yt-formatted-string > a";
const AUTHOUR_NAME_SELECTOR =
  "#metapanel > yt-reel-metapanel-view-model > div:nth-child(1) > yt-reel-channel-bar-view-model > span > a";
const AUTHOUR_NAME_SELECTOR_2 =
  "#metapanel > yt-reel-metapanel-view-model > div:nth-child(2) > yt-reel-channel-bar-view-model > span > a";
const NEXT_BUTTON_SELECTOR =
  "#navigation-button-down > ytd-button-renderer > yt-button-shape > button";
const PREVIOUS_BUTTON_SELECTOR =
  "#navigation-button-up > ytd-button-renderer > yt-button-shape > button";
// ------------------------------
// APP VARIABLES
// ------------------------------
let shortCutToggleKeys = [];
let shortCutInteractKeys = [];
let scrollOnCommentsCheck = false;
let scrollDirection = 1;
let amountOfPlays = 0;
let amountOfPlaysToSkip = 1;
let filterMinLength = "none";
let filterMaxLength = "none";
let filterMinViews = "none";
let filterMaxViews = "none";
let filterMinLikes = "none";
let filterMaxLikes = "none";
let filterMinComments = "none";
let filterMaxComments = "none";
let blockedCreators = [];
let whitelistedCreators = [];
let blockedTags = [];
let scrollOnNoTags = false;
let additionalScrollDelay = 0;
let showOnScreenButton = true;
// ------------------------------
// STATE VARIABLES
// ------------------------------
let currentShortId = null;
let currentVideoElement = null;
let applicationIsOn = false;
let onScreenToggleButton = null;
let scrollTimeout;
const MAX_RETRIES = 15;
const RETRY_DELAY_MS = 500;
// ------------------------------
// MAIN FUNCTIONS
// ------------------------------
function startAutoScrolling() {
  if (!applicationIsOn) {
    applicationIsOn = true;
    amountOfPlays = 0;
    currentShortId = null;
    currentVideoElement = null;
  }
  checkForNewShort();
  updateOnScreenButtonState();
}
function stopAutoScrolling() {
  applicationIsOn = false;
  amountOfPlays = 0;
  if (currentVideoElement) {
    currentVideoElement.setAttribute("loop", "true");
    currentVideoElement.removeEventListener("ended", shortEnded);
    currentVideoElement._hasEndEvent = false;
  }
  updateOnScreenButtonState();
}
async function checkForNewShort() {
  if (!applicationIsOn || !isShortsPage()) return;

  checkAndManageOnScreenButton();

  const currentShort = findShortContainer();
  if (!currentShort) return;
  // Checks if the current short is the same as the last one
  if (currentShort?.id != currentShortId) {
    // Prevent scrolling from previous short ending
    if (scrollTimeout) clearTimeout(scrollTimeout);
    // Remove event listener from the previous video element
    const previousShort = currentVideoElement;
    if (previousShort) {
      previousShort.removeEventListener("ended", shortEnded);
      previousShort._hasEndEvent = false;
    }
    // Set the new current short id and video element
    currentShortId = parseInt(currentShort.id);
    currentVideoElement = currentShort.querySelector("video");
    // Looping check if the current short has a video element
    if (currentVideoElement == null) {
      let l = 0;
      while (currentVideoElement == null) {
        currentVideoElement = currentShort.querySelector("video");
        if (l > MAX_RETRIES) {
          // If the video element is not found, scroll to the next short
          let prevShortId = currentShortId;
          currentShortId = null;
          console.log(
            "[Auto Youtube Shorts Scroller] Video element not found, scrolling to next short..."
          );
          return scrollToNextShort(prevShortId);
        }
        await new Promise((resolve) => setTimeout(resolve, RETRY_DELAY_MS));
        l++;
      }
    }
    // Check if the current short is an ad
    if (
      currentShort.querySelector("ytd-ad-slot-renderer") ||
      currentShort.querySelector("ad-button-view-model")
    ) {
      console.log(
        "[Auto Youtube Shorts Scroller] Ad detected..., scrolling to next short..."
      );
      // Make sure to remove any existing button before skipping
      removeOnScreenToggleButton();
      return scrollToNextShort(currentShortId, false);
    }
    // Log the current short id
    console.log(
      "[Auto Youtube Shorts Scroller] Current ID of Short: ",
      currentShortId
    );
    // Add event listener to the current video element
    console.log(
      "[Auto Youtube Shorts Scroller] Adding event listener to video element...",
      currentVideoElement
    );
    currentVideoElement.addEventListener("ended", shortEnded);
    currentVideoElement._hasEndEvent = true;
    // Check if the current short has metadata
    const isMetaDataHydrated = (selector) => {
      return currentShort.querySelector(selector) != null;
    };
    if (!isMetaDataHydrated(AUTHOUR_NAME_SELECTOR)) {
      let l = 0;
      // If the creator name is not found, wait for it to load (A long with other data)
      while (!isMetaDataHydrated(AUTHOUR_NAME_SELECTOR)) {
        if (isMetaDataHydrated(AUTHOUR_NAME_SELECTOR_2)) break;
        if (l > MAX_RETRIES) {
          // If after time not found, scroll to next short
          let prevShortId = currentShortId;
          currentShortId = null;
          console.log(
            "[Auto Youtube Shorts Scroller] Metadata not hydrated, scrolling to next short..."
          );
          return scrollToNextShort(prevShortId, false);
        }
        await new Promise((resolve) => setTimeout(resolve, RETRY_DELAY_MS));
        l++;
      }
    }
    // Check if short meets the filter settings
    const isValidShort = await checkShortValidity(currentShort);
    if (!isValidShort) {
      console.log(
        "[Auto Youtube Shorts Scroller] Short doesn't meet the filter settings, scrolling to next short..."
      );
      return scrollToNextShort(currentShortId, true);
    }
  }
  // Force removal of the loop attribute if it exists
  if (currentVideoElement?.hasAttribute("loop") && applicationIsOn) {
    currentVideoElement.removeAttribute("loop");
  }
}
function shortEnded(e) {
  e.preventDefault();
  if (!applicationIsOn) return stopAutoScrolling();
  console.log(
    "[Auto Youtube Shorts Scroller] Short ended, scrolling to next short..."
  );
  amountOfPlays++;
  // Checks amount of plays to skip the short
  if (amountOfPlays >= amountOfPlaysToSkip) {
    // If its same or exceeded the amount of plays, scroll to the next short
    amountOfPlays = 0;
    scrollToNextShort(currentShortId);
  } else {
    // Otherwise, play the video again
    currentVideoElement.play();
  }
}
async function scrollToNextShort(
  prevShortId = null,
  useDelayAndCheckComments = true
) {
  if (!applicationIsOn) return stopAutoScrolling();
  const comments = document.querySelector(COMMENTS_SELECTOR);
  const isCommentsOpen = () => {
    const visibilityOfComments = comments?.attributes["VISIBILITY"]?.value;
    return visibilityOfComments === "ENGAGEMENT_PANEL_VISIBILITY_EXPANDED";
  };
  // Check if comments is open, and settings are set to scroll on comments
  if (comments && useDelayAndCheckComments) {
    if (isCommentsOpen() && !scrollOnCommentsCheck) {
      useDelayAndCheckComments = false; // If the comments are open, don't wait for the additional scroll delay when scrolling
      // If the comments are open, wait till they are closed (if the setting is set to scroll on comments)
      while (
        isCommentsOpen() && // Waits till the comments are closed
        !scrollOnCommentsCheck && // Stops if the setting is changed
        prevShortId == currentShortId // Stops if the short changes
      ) {
        await new Promise((resolve) => setTimeout(resolve, 100));
      }
    }
  }
  if (scrollTimeout) clearTimeout(scrollTimeout);
  if (additionalScrollDelay > 0 && useDelayAndCheckComments)
    // If the additional scroll delay is set, wait for it, and allow loop while delaying
    currentVideoElement.play();
  scrollTimeout = setTimeout(
    async () => {
      if (prevShortId != null && currentShortId != prevShortId) return; // If the short changed, don't scroll
      const nextShortContainer = await waitForNextShort();
      if (nextShortContainer == null && isShortsPage())
        return window.location.reload(); // If no next short is found, reload the page (Last resort)
      // If next short container is found, remove the current video element end event listener
      if (currentVideoElement) {
        currentVideoElement.removeEventListener("ended", shortEnded);
        currentVideoElement._hasEndEvent = false;
      }
      // Scroll to the next short container
      nextShortContainer.scrollIntoView({
        behavior: "smooth",
        block: "nearest",
        inline: "start",
      });

      // Then check the new short
      checkForNewShort();

      // Ensure the button is properly managed after scrolling
      setTimeout(() => {
        checkAndManageOnScreenButton();
      }, 500); // Small delay to ensure DOM is updated
    },
    // Sets the additional scroll delay from settings
    useDelayAndCheckComments ? additionalScrollDelay : 0
  );
}
function findShortContainer(id = null) {
  let shorts = [];
  // Finds the short container by the selector (Incase of updates)
  for (let i = 0; i < VIDEOS_LIST_SELECTORS.length; i++) {
    const shortList = [...document.querySelectorAll(VIDEOS_LIST_SELECTORS[i])];
    if (shortList.length > 0) {
      shorts = [...shortList];
      break;
    }
  }
  // If an id is provided, find the short with that id
  if (id != null) {
    if (shorts.length === 0) return document.getElementById(id); // Short container should always contain id of the short order.
    const short = shorts.find((short) => short.id == id.toString());
    if (short) return short;
  }
  // If no shorts are found, return the first short with the id of 0
  if (shorts.length === 0) return document.getElementById(currentShortId || 0);
  // If no id is provided, find the first short with the is-active attribute
  // If id is provided, return short with id index from shorts list selector
  return id > 1
    ? shorts[id]
    : shorts.find(
        (short) =>
          // Active short either has the is-active attribute or a hydrated HTML of short.
          short.hasAttribute("is-active") ||
          short.querySelector(CURRENT_SHORT_SELECTOR) ||
          short.querySelector("[is-active]")
      ) || shorts[0] /*If no short found, return first short */;
}
async function waitForNextShort(retries = 5, delay = 500) {
  if (!isShortsPage()) return null;
  for (let i = 0; i < retries; i++) {
    // Find the next short container
    const nextShort = findShortContainer(currentShortId + scrollDirection);
    if (nextShort) return nextShort;
    // If none found, little slight screen shake to trigger hydration of new shorts
    window.scrollBy(0, 100);
    await new Promise((r) => setTimeout(r, delay));
    window.scrollBy(0, -100);
    await new Promise((r) => setTimeout(r, delay));
  }
  console.log(
    "[Auto Youtube Shorts Scroller] The next short has not loaded in, reloading page..."
  );
  return null;
}

function createOnScreenToggleButton() {
  if (onScreenToggleButton || !showOnScreenButton) return;

  const likeButton = document.querySelector(LIKE_BUTTON_SELECTOR);
  if (!likeButton) return;

  const buttonContainer =
    likeButton.closest("#like-button") ||
    likeButton.closest('[role="button"]') ||
    likeButton.closest("ytd-toggle-button-renderer") ||
    likeButton.parentElement;
  if (!buttonContainer) return;

  const actionBar = buttonContainer.parentElement;
  if (!actionBar) return;

  const toggleButton = document.createElement("div");
  toggleButton.id = "yt-shorts-auto-scroll-toggle";
  toggleButton.innerHTML = `
        <div style="
            width: 48px;
            height: 48px;
            border-radius: 50%;
            background: transparent;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            margin: 0 auto 19px auto;
            transition: all 0.2s ease;
            position: relative;
            ${
              applicationIsOn
                ? "box-shadow: 0 0 10px 2px rgba(255, 0, 0, 0.2);"
                : ""
            }
        " title="${
          applicationIsOn
            ? "Auto-scroll ON - Click to disable"
            : "Auto-scroll OFF - Click to enable"
        }">
            <div style="
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                height: 100%;
                position: relative;
            ">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" style="
                    color: ${applicationIsOn ? "#FF0000" : "#AAAAAA"};
                    transition: color 0.2s ease, transform 0.2s ease;
                    filter: ${
                      applicationIsOn
                        ? "drop-shadow(0 0 3px rgba(255, 0, 0, 0.5))"
                        : "none"
                    };
                    margin-bottom: 2px;
                ">
                    <path d="M7 10l5 5 5-5H7z" fill="currentColor"/>
                    <path d="M7 14l5 5 5-5H7z" fill="currentColor"/>
                </svg>
                <span style="
                    font-size: 11px;
                    line-height: 1;
                    color: ${applicationIsOn ? "#FF0000" : "#AAAAAA"};
                    font-family: 'Roboto', 'Arial', sans-serif;
                    font-weight: ${applicationIsOn ? "500" : "400"};
                    transition: color 0.2s ease;
                    ${
                      applicationIsOn
                        ? "text-shadow: 0 0 5px rgba(255, 0, 0, 0.3);"
                        : ""
                    }
                ">
                    ${applicationIsOn ? "ON" : "OFF"}
                </span>
            </div>
        </div>
        </div>
    `;

  // Add hover effect with JavaScript
  const buttonDiv = toggleButton.querySelector("div");
  buttonDiv.addEventListener("mouseenter", () => {
    const innerDiv = buttonDiv.querySelector("div");
    const svgElement = innerDiv.querySelector("svg");
    const textElement = innerDiv.querySelector("span");

    if (applicationIsOn) {
      buttonDiv.style.background = "rgba(255, 0, 0, 0.1)";
      svgElement.style.transform = "scale(1.1)";
    } else {
      buttonDiv.style.background = "rgba(255, 255, 255, 0.1)";
      svgElement.style.color = "#FFFFFF";
      textElement.style.color = "#FFFFFF";
    }
  });

  buttonDiv.addEventListener("mouseleave", () => {
    const innerDiv = buttonDiv.querySelector("div");
    const svgElement = innerDiv.querySelector("svg");
    const textElement = innerDiv.querySelector("span");

    buttonDiv.style.background = "transparent";
    svgElement.style.transform = "scale(1)";

    if (!applicationIsOn) {
      svgElement.style.color = "#AAAAAA";
      textElement.style.color = "#AAAAAA";
    }
  });

  toggleButton.addEventListener("click", (e) => {
    e.stopPropagation();
    e.preventDefault();

    if (applicationIsOn) {
      stopAutoScrolling();
      chrome.storage.local.set({ applicationIsOn: false });
    } else {
      startAutoScrolling();
      chrome.storage.local.set({ applicationIsOn: true });
    }

    updateOnScreenButtonState();
  });

  actionBar.insertBefore(toggleButton, buttonContainer);
  onScreenToggleButton = toggleButton;
  console.log("[Auto Youtube Shorts Scroller] On-screen toggle button created");
}

function updateOnScreenButtonState() {
  if (!onScreenToggleButton) return;

  const buttonElement = onScreenToggleButton.querySelector("div");
  const innerDiv = buttonElement?.querySelector("div");
  const svgElement = innerDiv?.querySelector("svg");
  const textElement = innerDiv?.querySelector("span");

  if (buttonElement) {
    buttonElement.title = applicationIsOn
      ? "Auto-scroll ON - Click to disable"
      : "Auto-scroll OFF - Click to enable";

    // Add or remove glow effect
    if (applicationIsOn) {
      buttonElement.style.boxShadow = "0 0 10px 2px rgba(255, 0, 0, 0.2)";
    } else {
      buttonElement.style.boxShadow = "none";
      buttonElement.style.background = "transparent";
    }

    if (svgElement) {
      svgElement.style.color = applicationIsOn ? "#FF0000" : "#AAAAAA";
      svgElement.style.filter = applicationIsOn
        ? "drop-shadow(0 0 3px rgba(255, 0, 0, 0.5))"
        : "none";
      svgElement.style.transform = "scale(1)";
    }

    if (textElement) {
      textElement.textContent = applicationIsOn ? "ON" : "OFF";
      textElement.style.color = applicationIsOn ? "#FF0000" : "#AAAAAA";
      textElement.style.fontWeight = applicationIsOn ? "500" : "400";
      textElement.style.textShadow = applicationIsOn
        ? "0 0 5px rgba(255, 0, 0, 0.3)"
        : "none";
    }
  }
}

function removeOnScreenToggleButton() {
  if (onScreenToggleButton) {
    onScreenToggleButton.remove();
    onScreenToggleButton = null;
    console.log(
      "[Auto Youtube Shorts Scroller] On-screen toggle button removed"
    );
  }
}

function checkAndManageOnScreenButton() {
  if (showOnScreenButton && isShortsPage()) {
    if (!onScreenToggleButton) {
      createOnScreenToggleButton();
    } else {
      updateOnScreenButtonState();
    }
  } else {
    removeOnScreenToggleButton();
  }
}

async function checkShortValidity(currentShort) {
  const videoLength = currentVideoElement?.duration;
  const viewCount = document.querySelector(VIEW_COUNT_SELECTOR);
  const likeCount = document.querySelector(LIKES_COUNT_SELECTOR);
  const commentCount =
    currentShort &&
    currentShort.querySelector(COMMENTS_COUNT_SELECTORS.join(","));
  const tags = document.querySelectorAll(DESCRIPTION_TAGS_SELECTOR);
  const creatorName =
    currentShort &&
    (currentShort.querySelector(AUTHOUR_NAME_SELECTOR) ||
      currentShort.querySelector(AUTHOUR_NAME_SELECTOR_2));
  console.log("[Auto Youtube Shorts Scroller]", {
    filters: [
      { videoLength, filterMinLength, filterMaxLength },
      { viewCount: viewCount?.innerText, filterMinViews, filterMaxViews },
      { likeCount: likeCount?.innerText, filterMinLikes, filterMaxLikes },
      {
        commentCount: commentCount?.innerText,
        filterMinComments,
        filterMaxComments,
      },
      { tags: [...tags].map((tag) => tag.innerText) },
      { creatorName: creatorName?.innerText },
      { blockedTags },
      { blockedCreators },
      { whitelistedCreators },
    ],
  });
  if (!creatorName || !commentCount) return false;
  // Ignores all checks if whitelisted creator
  if (whitelistedCreators.length > 0) {
    const creator = creatorName.innerText.trim().toLowerCase();
    if (
      whitelistedCreators.map((cr) => cr.toLowerCase()).includes(creator) ||
      whitelistedCreators
        .map((cr) => cr.toLowerCase())
        .includes(creator.replace("@", ""))
    ) {
      return true;
    }
  }
  if (!checkValidVideoLength(videoLength)) return false;
  if (viewCount && !checkValidViewCount(viewCount)) return false;
  if (likeCount && !checkValidLikeCount(likeCount)) return false;
  if (!checkValidCommentCount(commentCount)) return false;
  if (!checkValidTags(tags)) return false;
  if (!checkValidCreator(creatorName)) return false;
  function checkValidVideoLength(videoLength) {
    if (filterMinLength !== "none" && videoLength < parseInt(filterMinLength))
      return false;
    if (filterMaxLength !== "none" && videoLength > parseInt(filterMaxLength))
      return false;
    return true;
  }
  function checkValidViewCount(viewCount) {
    const viewCountText = viewCount.innerText
      .trim()
      .toLowerCase()
      .replaceAll(",", "");
    const filterMinViewsParsed = parseTextToNumber(filterMinViews);
    const filterMaxViewsParsed = parseTextToNumber(filterMaxViews);
    if (
      filterMinViews !== "none" &&
      parseInt(viewCountText) < filterMinViewsParsed
    )
      return false;
    if (
      filterMaxViews !== "none" &&
      parseInt(viewCountText) > filterMaxViewsParsed
    )
      return false;
    return true;
  }
  function checkValidLikeCount(likeCount) {
    const likeNum = parseTextToNumber(likeCount.innerText);
    const filterMinLikesParsed = parseTextToNumber(filterMinLikes);
    const filterMaxLikesParsed = parseTextToNumber(filterMaxLikes);
    if (filterMinLikes !== "none" && likeNum < filterMinLikesParsed)
      return false;
    if (filterMaxLikes !== "none" && likeNum > filterMaxLikesParsed)
      return false;
    return true;
  }
  function checkValidCommentCount(commentCount) {
    const commentNum = parseTextToNumber(commentCount.innerText);
    const filterMinCommentsParsed = parseTextToNumber(filterMinComments);
    const filterMaxCommentsParsed = parseTextToNumber(filterMaxComments);
    if (filterMinComments !== "none" && commentNum < filterMinCommentsParsed)
      return false;
    if (filterMaxComments !== "none" && commentNum > filterMaxCommentsParsed)
      return false;
    return true;
  }
  function checkValidTags(tags) {
    if (tags.length === 0 && scrollOnNoTags) return false;
    for (let i = 0; i < tags.length; i++) {
      const tag = tags[i].innerText.toLowerCase();
      if (
        blockedTags.map((bTag) => bTag.toLowerCase()).includes(tag) ||
        blockedTags
          .map((bTag) => bTag.toLowerCase())
          .includes(tag.replace("#", ""))
      )
        return false;
    }
    return true;
  }
  function checkValidCreator(creatorName) {
    const creator = creatorName.innerText.trim().toLowerCase();
    if (
      blockedCreators.map((cr) => cr.toLowerCase()).includes(creator) ||
      blockedCreators
        .map((cr) => cr.toLowerCase())
        .includes(creator.replace("@", ""))
    )
      return false;
    return true;
  }
  // If all checks pass, return true
  return true;
}
// ------------------------------
// INITIATION AND SETTINGS FETCH
// ------------------------------
(function initiate() {
  chrome.storage.local.get(["applicationIsOn"], (result) => {
    if (result["applicationIsOn"] == null) return startAutoScrolling();
    if (result["applicationIsOn"]) startAutoScrolling();
  });
  checkForNewShort();
  checkApplicationState();
  // Set up intervals for periodic checks
  setInterval(checkForNewShort, RETRY_DELAY_MS);
  setInterval(checkAndManageOnScreenButton, 1000); // Reduced from 2000ms to 1000ms for more responsive button appearance
  function checkApplicationState() {
    chrome.storage.local.get(["applicationIsOn"], (result) => {
      if (applicationIsOn && result["applicationIsOn"] === false) {
        stopAutoScrolling();
      } else if (result["applicationIsOn"] === true) {
        startAutoScrolling();
      }
    });
  }
  (function onApplicationChange() {
    chrome.storage.local.onChanged.addListener((changes) => {
      if (changes["applicationIsOn"]?.newValue) {
        startAutoScrolling();
      } else if (changes["applicationIsOn"]?.newValue === false) {
        stopAutoScrolling();
      }
    });
  })();
  (function getAllSettings() {
    chrome.storage.local.get(
      [
        "shortCutKeys",
        "shortCutInteractKeys",
        "scrollDirection",
        "amountOfPlaysToSkip",
        "filterByMinLength",
        "filterByMaxLength",
        "filterByMinViews",
        "filterByMaxViews",
        "filterByMinLikes",
        "filterByMaxLikes",
        "filterByMinComments",
        "filterByMaxComments",
        "filteredAuthors",
        "filteredTags",
        "scrollOnComments",
        "scrollOnNoTags",
        "whitelistedAuthors",
        "additionalScrollDelay",
        "showOnScreenButton",
      ],
      (result) => {
        console.log("[Auto Youtube Shorts Scroller]", {
          AutoYTScrollerSettings: result,
        });
        if (result["shortCutKeys"])
          shortCutToggleKeys = [...result["shortCutKeys"]];
        if (result["shortCutInteractKeys"])
          shortCutInteractKeys = [...result["shortCutInteractKeys"]];
        if (result["scrollDirection"]) {
          if (result["scrollDirection"] === "up") scrollDirection = -1;
          else scrollDirection = 1;
        }
        if (result["amountOfPlaysToSkip"])
          amountOfPlaysToSkip = result["amountOfPlaysToSkip"];
        if (result["scrollOnComments"])
          scrollOnCommentsCheck = result["scrollOnComments"];
        if (result["filterByMinLength"])
          filterMinLength = result["filterByMinLength"];
        if (result["filterByMaxLength"])
          filterMaxLength = result["filterByMaxLength"];
        if (result["filterByMinViews"])
          filterMinViews = result["filterByMinViews"];
        if (result["filterByMaxViews"])
          filterMaxViews = result["filterByMaxViews"];
        if (result["filterByMinLikes"])
          filterMinLikes = result["filterByMinLikes"];
        if (result["filterByMaxLikes"])
          filterMaxLikes = result["filterByMaxLikes"];
        if (result["filterByMinComments"])
          filterMinComments = result["filterByMinComments"];
        if (result["filterByMaxComments"])
          filterMaxComments = result["filterByMaxComments"];
        if (result["filteredAuthors"])
          blockedCreators = [...result["filteredAuthors"]];
        if (result["filteredTags"]) blockedTags = [...result["filteredTags"]];
        if (result["whitelistedAuthors"])
          whitelistedCreators = [...result["whitelistedAuthors"]];
        if (result["scrollOnNoTags"]) scrollOnNoTags = result["scrollOnNoTags"];
        if (result["additionalScrollDelay"])
          additionalScrollDelay = result["additionalScrollDelay"];
        if (result["showOnScreenButton"] !== undefined)
          showOnScreenButton = result["showOnScreenButton"];
        shortCutListener();
      }
    );
    chrome.storage.onChanged.addListener(async (result) => {
      let newShortCutKeys = result["shortCutKeys"]?.newValue;
      if (newShortCutKeys != undefined) {
        shortCutToggleKeys = [...newShortCutKeys];
      }
      let newShortCutInteractKeys = result["shortCutInteractKeys"]?.newValue;
      if (newShortCutInteractKeys != undefined) {
        shortCutInteractKeys = [...newShortCutInteractKeys];
      }
      let newScrollDirection = result["scrollDirection"]?.newValue;
      if (newScrollDirection != undefined) {
        if (newScrollDirection === "up") scrollDirection = -1;
        else scrollDirection = 1;
      }
      let newAmountOfPlaysToSkip = result["amountOfPlaysToSkip"]?.newValue;
      if (newAmountOfPlaysToSkip) {
        amountOfPlaysToSkip = newAmountOfPlaysToSkip;
      }
      let newScrollOnComments = result["scrollOnComments"]?.newValue;
      if (newScrollOnComments !== undefined) {
        scrollOnCommentsCheck = newScrollOnComments;
      }
      let newFilterMinLength = result["filterByMinLength"]?.newValue;
      if (newFilterMinLength != undefined) {
        filterMinLength = newFilterMinLength;
      }
      let newFilterMaxLength = result["filterByMaxLength"]?.newValue;
      if (newFilterMaxLength != undefined) {
        filterMaxLength = newFilterMaxLength;
      }
      let newFilterMinViews = result["filterByMinViews"]?.newValue;
      if (newFilterMinViews != undefined) {
        filterMinViews = newFilterMinViews;
      }
      let newFilterMaxViews = result["filterByMaxViews"]?.newValue;
      if (newFilterMaxViews != undefined) {
        filterMaxViews = newFilterMaxViews;
      }
      let newFilterMinLikes = result["filterByMinLikes"]?.newValue;
      if (newFilterMinLikes != undefined) {
        filterMinLikes = newFilterMinLikes;
      }
      let newFilterMaxLikes = result["filterByMaxLikes"]?.newValue;
      if (newFilterMaxLikes != undefined) {
        filterMaxLikes = newFilterMaxLikes;
      }
      let newFilterMinComments = result["filterByMinComments"]?.newValue;
      if (newFilterMinComments != undefined) {
        filterMinComments = newFilterMinComments;
      }
      let newFilterMaxComments = result["filterByMaxComments"]?.newValue;
      if (newFilterMaxComments != undefined) {
        filterMaxComments = newFilterMaxComments;
      }
      let newBlockedCreators = result["filteredAuthors"]?.newValue;
      if (newBlockedCreators != undefined) {
        blockedCreators = [...newBlockedCreators];
      }
      let newBlockedTags = result["filteredTags"]?.newValue;
      if (newBlockedTags != undefined) {
        blockedTags = [...result["filteredTags"]?.newValue];
      }
      let newWhiteListedCreators = result["whitelistedAuthors"]?.newValue;
      if (newWhiteListedCreators != undefined) {
        whitelistedCreators = [...newWhiteListedCreators];
      }
      let newScrollOnNoTags = result["scrollOnNoTags"]?.newValue;
      if (newScrollOnNoTags !== undefined) {
        scrollOnNoTags = newScrollOnNoTags;
      }
      let newAdditionalScrollDelay = result["additionalScrollDelay"]?.newValue;
      if (newAdditionalScrollDelay !== undefined) {
        additionalScrollDelay = newAdditionalScrollDelay;
      }
      let newShowOnScreenButton = result["showOnScreenButton"]?.newValue;
      if (newShowOnScreenButton !== undefined) {
        showOnScreenButton = newShowOnScreenButton;
        checkAndManageOnScreenButton();
      }
      if (!(await checkShortValidity(findShortContainer(currentShortId)))) {
        scrollToNextShort(currentShortId);
      }
    });
  })();
})();
function shortCutListener() {
  let pressedKeys = [];
  // Web Dev Simplifed Debounce
  function debounce(cb, delay) {
    let timeout;
    return (...args) => {
      clearTimeout(timeout);
      timeout = setTimeout(() => {
        cb(...args);
      }, delay);
    };
  }
  const checkKeys = (keysToCheck, waitDebounce = true, delay = 700) => {
    return new Promise((resolve) => {
      function debounceCB() {
        if (pressedKeys.length == keysToCheck.length) {
          let match = true;
          for (let i = 0; i < pressedKeys.length; i++) {
            if (pressedKeys[i] != keysToCheck[i]) {
              match = false;
              break;
            }
          }
          resolve(match);
        } else resolve(false);
      }
      if (waitDebounce) debounce(debounceCB, delay)();
      else debounceCB();
    });
  };
  document.addEventListener("keydown", async (e) => {
    if (!e.key) return;
    pressedKeys.push(e.key.toLowerCase());
    // Shortcut for toggle application on/off
    if (await checkKeys(shortCutToggleKeys)) {
      if (applicationIsOn) {
        stopAutoScrolling();
        chrome.storage.local.set({
          applicationIsOn: false,
        });
      } else {
        startAutoScrolling();
        chrome.storage.local.set({
          applicationIsOn: true,
        });
      }
    } else if (await checkKeys(shortCutInteractKeys, false)) {
      // Shortcut for like/dislike
      const likeBtn = document.querySelector(LIKE_BUTTON_SELECTOR);
      const dislikeBtn = document.querySelector(DISLIKE_BUTTON_SELECTOR);
      if (
        likeBtn?.getAttribute("aria-pressed") === "true" ||
        dislikeBtn?.getAttribute("aria-pressed") === "true"
      ) {
        dislikeBtn.click();
      } else {
        likeBtn.click();
      }
    }
    pressedKeys = [];
  });
}
function isShortsPage() {
  let containsShortElements = false;
  const doesPageHaveAShort = document.querySelector(
    VIDEOS_LIST_SELECTORS.join(",")
  );
  if (doesPageHaveAShort) containsShortElements = true;
  return containsShortElements;
}
function parseTextToNumber(text) {
  text = text.trim().toLowerCase();
  if (text.endsWith("k")) {
    return parseFloat(text) * 1_000;
  }
  if (text.endsWith("m")) {
    return parseFloat(text) * 1_000_000;
  }
  return parseInt(text.replace(/,/g, "")) || 0; // Handle normal numbers like "933"
}
